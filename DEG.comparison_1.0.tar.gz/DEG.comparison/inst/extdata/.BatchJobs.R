cluster.functions <- makeClusterFunctionsTorque("torque.tmpl")
